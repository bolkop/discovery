from PyQt4 import QtCore, QtGui, Qt
from PyQt4.QtGui import QApplication, QCursor

from netdisc import netdisc
from pccontrol import pccontrol

import ModSetupWithTree as ms

class MyQtApp(ms.Ui_MainWindow, QtGui.QMainWindow):
    __ntd = netdisc() # object class netdisc
    
    __localPc = None
    __localDevicesList = ["Dev10 24323, fdsfs, fsdfs, fssdf"\
                            , "Dev1 54881 dsfdf gsdjkls ds;djfk sdlkf;"\
                            ,"TestDEV-8: 140.10.10.2 ELEC MODEM"]  # Global list to hold all discovered local devices                             
    __remoteDevicesList = []   # Global list to hold all discovered remote devices
    __selectedLocalDevice = None  # Global variable for selected local device 
    __selectedRemoteDevice = None  # Global variable for selected global device 
    __localConfigXmlFile = None   # Configuration .xml File for local device
    __remoteConfigXmlFile = None   # Configuration .xml File for remote device
    __localConfigFtpFile = None   # Configuration .ftp File for local device
    __remoteConfigFtpFile = None   # Configuration .ftp File for remote device
  
    __testList = ["Dev10 24323, fdsfs, fsdfs, fssdf"\
                            , "Dev1 54881 dsfdf gsdjkls ds;djfk sdlkf;"\
                            ,"TestDEV-8: 140.10.10.2 ELEC MODEM"]  
    
    def __init__(self):
        super(MyQtApp, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("Network Scanner -  Build 01")     
        self.initTree()
        #self.treeWidget.itemClicked.connect(self.showWidgetDetails)
        self.stackedWidget.setCurrentIndex(0)
        self.pushButtonPc.clicked.connect(self.scanLocal)
       
    
    def waiting_effects(function):
        def new_function(self):
            QApplication.setOverrideCursor(QCursor(QtCore.Qt.WaitCursor))
            try:
                function(self)
            except ValueError as e:
                QApplication.restoreOverrideCursor()
                self.showdialog(e.args[0])
               # self.clearDevicesFromTree()
                raise e                         
            finally:
                QApplication.restoreOverrideCursor()
        return new_function
        
    # def showWidgetDetails(self, it, col):
        # print(it, col, it.text(col))
  
        # self.stackedWidget.setCurrentIndex(col)
         
                 
    def initTree(self):
        """
        Clear Items in Tree Widget.
        Check details TCP/IP details of host PC.
        Update Tree and Widget with host PC details.       
        """
        self.treeWidget.takeTopLevelItem(0)
        self.treeWidget.setHeaderLabels(["Network Devices"])
        pcIpAddress = self.__ntd.get_IP()
        self.__localPc = QtGui.QTreeWidgetItem(['Local PC ' + pcIpAddress])
        self.treeWidget.addTopLevelItem(self.__localPc)
        self.lineEditPcPhysicalAddress.clear()
        self.lineEditPcPhysicalAddress.setText((unicode(self.__ntd.get_MAC())))
        self.lineEditPcIpAddress.setText(unicode(pcIpAddress))
        self.lineEditPcSubnetMask.setText(unicode(self.__ntd.get_SubnetMask()))
        self.lineEditPcDefaultGateway.setText(unicode(self.__ntd.get_DefaultGateway()))
        self.stackedWidget.setCurrentIndex(0)
        self.treeWidget.itemClicked.connect(lambda: self.printInfo(self.treeWidget.currentItem()))
        self.addLocalDevicesToTree(self.__localDevicesList) #only for test purpose
        
    def pcDetals(self):
        print "pc details"
        
        
    @waiting_effects
    def scanLocal(self):
        """
        Search for local devices on a network and list them in Tree Widget window.
        If there are no devices found the Tree window is cleared.
        """
        # Clear content of "Local Devices List" window
        #self.discoveredLocalDev.clear()
        
        # Clear content of "Interface Detail" window
        #self.detailsLocalDev.clear()

        # Search for local devices
        devices = self.__ntd.doLocalScan()       
            
        if devices is False:
            # Did not find local devices
            raise ValueError("Unable to find local devices")
        
        else:
            # Update list of local devices
            newLocalDevices = []
            discoveredDevices = []
            lineSplited = devices.splitlines()
            
            for dev in lineSplited:
                devSplited = dev.split()
                tmp = " ".join([devSplited[index] for index in [0,2,3,4]])                
                discoveredDevices.append(tmp)
                if tmp in self.__localDevicesList:
                    None
                else:
                    newLocalDevices.append(tmp)
                    self.__localDevicesList.append(tmp)
            
          #  print("discovered dev ", discoveredDevices)       
            self.__localDevicesList= list((set(discoveredDevices) & set(self.__localDevicesList)))           
            
            #print ("new devices", newLocalDevices )
           # print ("updated list", self.__localDevicesList)
            self.addLocalDevicesToTree(newLocalDevices)
        
    # def updateDiscoveredDeviceList(self):
        # """
        # Add discovered devices to Tree window from global __localDevicesList.
        # """
        # print (self.__localDevicesList[0])
        # if self.__localDevicesList[0] == "None":
            # self.clearDevicesFromTree()
        # else:
            # self.addLocalDevicesToTree(self._localDevicesList)
            

    def addLocalDevicesToTree(self, devicesList):        
        """
        Add new devices to tree widget
        Remove not existing devices from tree widget
        IN list of devices to be added
        """
 
        # Add all dev from list before updates
        for dev in devicesList:   
            localDev = QtGui.QTreeWidgetItem(self.__localPc, 1)
            localDev.setText(0, dev)
       
       # Remove all non-existing local devices from tree   
        for dev in self.__localDevicesList:
            for index in range(self.__localPc.childCount()):
                if unicode(self.__localPc.child(index).text(0)) not in self.__localDevicesList:
                     self.__localPc.takeChild(index)
                     break
        
        # Show all branches         
        self.treeWidget.expandAll()  
    
   # @waiting_effects    
    def printInfo(self, device):
        """
        Print eth and fifo details in "Device Interface Details" window
        """
      
        # Obtain type of selected device and open correct window
        devType = device.type()
        self.stackedWidget.setCurrentIndex(devType)
     
        # Local Device is type 1
        if devType == 1:
            # Obtain local device name "DEV-?"
            self.selectedLocalDevice = unicode(device.text(0)).split(' ', 1)
            selected = self.selectedLocalDevice
            #print(selected)
       
        else:
            selected = "None"
            # # Obtain remote device name "DEV-?"
            # self.selectedRemoteDevice = dev.split(' ', 1)
            # selected = self.selectedRemoteDevice
                  
        if "DEV" in selected[0]:           
            results = self.__ntd.do_print(unicode(selected[0]))
            print results
            self.updateWindow(devType, results)
        else:
            print("clear window")
            self.clearWindow(devType)
    

    def updateWindow(self, type, details):
        
        if details:
            if type == 1:
                lineSplited = details.splitlines()
                #print(lineSplited)
                for line in lineSplited:
                    
                    if line.startswith("eth0"):
                        lineSplited = line.split()
                        tmp = "".join(lineSplited[1])
                        self.lineEditLocalEth0Ip.setText(tmp)
                        tmp = "".join(lineSplited[2])
                        self.lineEditLocalEth0MacAddress.setText(tmp)
                   
                    elif line.startswith("fifo0"):
                        lineSplited = line.split()
                        tmp = "".join(lineSplited[1])
                        self.lineEditFifo0IpAddress.setText(tmp)
                        tmp = "".join(lineSplited[2])
                        self.lineEditLocalFifo0MacAddress.setText(tmp)
                    
                    elif line.startswith("fifo1"):
                        lineSplited = line.split()
                        tmp = "".join(lineSplited[1])
                        self.lineEditFifo1IpAddress.setText(tmp)
                        tmp = "".join(lineSplited[2])
                        self.lineEditLocalFifo1MacAddress.setText(tmp)    
        
        
    def clearWindow(self, type):
            if type == 1:              
                self.lineEditLocalEth0Ip.clear()
                self.lineEditLocalEth0MacAddress.clear()                                
                self.lineEditFifo0IpAddress.clear()                
                self.lineEditLocalFifo0MacAddress.clear()                      
                self.lineEditFifo1IpAddress.clear()               
                self.lineEditLocalFifo1MacAddress.clear()  
                self.textEditLocalRoute.clear()
                self.textEditLocalBackRoute.clear()
    
    def clearDevicesFromTree(self):
        print ("All deviced removed from tree")
        None
            
    def showdialog(self, text):
        """
        Display window message type info.
        Text parameter as string is displayed
        Message window includes OK button
        """
        msg = QtGui.QMessageBox()
        msg.setWindowTitle("Info")
        msg.setIcon(QtGui.QMessageBox.Information)
        msg.setText(text+"\t\n\n")
        msg.setStandardButtons(QtGui.QMessageBox.Ok)   
        msg.exec_()
    

def mainFunc():
    import sys

    app = QtGui.QApplication(sys.argv)
    qtApp = MyQtApp()
    qtApp.show()
    app.exec_()

if __name__ == '__main__':
    mainFunc()