from PyQt4 import QtCore, QtGui

class PcPropertiesDialog(QtGui.QDialog):
    
    def __init__(self, parent=None):
        super(PcPropertiesDialog, self).__init__(parent)
        
        self.labelPhysicalAddress = QtGui.QLabel("Physical Address")
        self.physicalAddress = QtGui.QLineEdit()
        
        self.labelIpAddress = QtGui.QLabel("IP Address")
        self.ipAddress = QtGui.QLineEdit()
        
        self.labelSubnetMask = QtGui.QLabel("Subnet Mask")
        self.subnetMask = QtGui.QLineEdit()
        
        self.labelDefaultGateway = QtGui.QLabel("Default Gateway")
        self.defaultGateway = QtGui.QLineEdit()
        
        okButton = QtGui.QPushButton("&OK")
        cancelButton = QtGui.QPushButton("Cancel")
        
        buttonLayout = QtGui.QHBoxLayout()
        buttonLayout.addStretch()
        buttonLayout.addWidget(okButton)
        buttonLayout.addWidget(cancelButton)
        spacerItem = QtGui.QSpacerItem(20, 30, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        layout = QtGui.QGridLayout()
        layout.addWidget(self.labelPhysicalAddress, 0, 0)
        layout.addWidget(self.physicalAddress, 0, 1)
        layout.addWidget(self.labelIpAddress, 1, 0)
        layout.addWidget(self.ipAddress, 1, 1)
        layout.addWidget(self.labelSubnetMask, 2, 0)
        layout.addWidget(self.subnetMask, 2, 1)
        layout.addWidget(self.labelDefaultGateway, 3, 0)
        layout.addWidget(self.defaultGateway, 3, 1)
        layout.addItem(spacerItem, 4,0,1,2)
        layout.addLayout(buttonLayout, 5, 0,1,2)
        layout.setContentsMargins(20, -1, 30, -1)
        layout.setHorizontalSpacing(60)
        layout.setVerticalSpacing(5)
        self.setLayout(layout)
        
        self.connect(okButton, QtCore.SIGNAL("clicked()"), self, QtCore.SLOT("accept()"))
        self.connect(cancelButton, QtCore.SIGNAL("clicked()"), self, QtCore.SLOT("reject()"))
        
        self.setWindowTitle("Change IP Details")
        

def mainFunc():
    import sys
    app = QtGui.QApplication(sys.argv)
    dialog = PcPropertiesDialog()
    dialog.show()
    app.exec_()
    

if __name__ == '__main__':
    mainFunc()      
        